<?php
/**
 * bootstrap.php - Modifications P0
 * Ajout des services DI pour les composants de fiabilitÃ©
 */

// ============================================
// NOUVEAUX USE STATEMENTS Ã  AJOUTER
// ============================================
use EasyLocalAI\Core\Observability\TraceContext;
use EasyLocalAI\Core\Observability\TelemetryLogger;
use EasyLocalAI\Tools\Policy\ToolPolicyEngine;
use EasyLocalAI\Tools\Policy\PolicyDecision;
use EasyLocalAI\Core\Safety\HitlGate;
use EasyLocalAI\Core\Safety\HitlRequiredException;
use EasyLocalAI\Core\Safety\GroundingVerifier;

// ============================================
// NOUVEAUX SERVICES DI Ã  ENREGISTRER
// ============================================

// Container::add('telemetry_logger', function(Container $c) {
//     $logFilePath = $c->get('config')['paths']['data'] ?? 'data/agent_traces.jsonl';
//     return new TelemetryLogger($logFilePath, enabled: true);
// });

// Container::add('tool_policy_engine', function(Container $c) {
//     $config = $c->get('config');
//     $policiesFile = $config['paths']['config'] ?? 'config/tool_policies.json';
//     
//     $policies = [];
//     if (file_exists($policiesFile)) {
//         $policies = json_decode(file_get_contents($policiesFile), true) ?? [];
//     }
//     
//     return new ToolPolicyEngine(
//         policies: $policies,
//         defaultMaxChainActions: $config['tool_policy']['default_max_chain_actions'] ?? 3,
//         defaultMaxCallsPerRequest: $config['tool_policy']['default_max_calls_per_request'] ?? 10,
//         defaultMaxDurationMs: $config['tool_policy']['default_max_duration_ms'] ?? 20000,
//         enforce: $config['tool_policy']['enforce'] ?? false  // Commencer en audit
//     );
// });

// Container::add('hitl_gate', function(Container $c) {
//     $config = $c->get('config');
//     $storagePath = $config['paths']['data'] ?? 'data' . DIRECTORY_SEPARATOR . 'hitl_decisions.json';
//     
//     return new HitlGate(
//         storagePath: $storagePath,
//         defaultTimeoutSeconds: $config['hitl']['default_timeout_seconds'] ?? 1800
//     );
// });

// Container::add('grounding_verifier', function(Container $c) {
//     $config = $c->get('config');
//     
//     return new GroundingVerifier(
//         minClaimSupportRatio: $config['grounding']['min_claim_support_ratio'] ?? 0.95,
//         enforce: $config['grounding']['enforce'] ?? false  // Commencer en audit
//     );
// });

// ============================================
// MODIFICATION CONSTRUCTION ToolRegistry
// ============================================

// ANCIEN:
// $toolRegistry = new ToolRegistry();

// NOUVEAU:
// $toolRegistry = new ToolRegistry(
//     policyEngine: $container->get('tool_policy_engine'),
//     hitlGate: $container->get('hitl_gate'),
//     telemetryLogger: $container->get('telemetry_logger')
// );

// ============================================
// CONFIGURATION EXEMPLE config/tool_policies.json
// ============================================
/*
{
  "tool_web_search": {
    "tool_id": "tool_web_search",
    "permission_level": "read",
    "max_chain_actions": 5,
    "max_calls_per_request": 10,
    "max_duration_ms": 30000,
    "requires_hitl": false,
    "estimated_token_cost": 500
  },
  "tool_file_write": {
    "tool_id": "tool_file_write",
    "permission_level": "write",
    "max_chain_actions": 3,
    "max_calls_per_request": 5,
    "max_duration_ms": 10000,
    "requires_hitl": true,
    "estimated_token_cost": 200
  },
  "tool_deploy": {
    "tool_id": "tool_deploy",
    "permission_level": "critical",
    "max_chain_actions": 1,
    "max_calls_per_request": 1,
    "max_duration_ms": 60000,
    "requires_hitl": true,
    "estimated_token_cost": 100
  }
}
*/

// ============================================
// EXEMPLE config/settings.json (ajouts)
// ============================================
/*
{
  "tool_policy": {
    "enforce": false,
    "default_max_chain_actions": 3,
    "default_max_calls_per_request": 10,
    "default_max_duration_ms": 20000
  },
  "hitl": {
    "default_timeout_seconds": 1800
  },
  "grounding": {
    "enforce": false,
    "min_claim_support_ratio": 0.95
  },
  "observability": {
    "enabled": true,
    "log_path": "data/agent_traces.jsonl"
  }
}
*/
