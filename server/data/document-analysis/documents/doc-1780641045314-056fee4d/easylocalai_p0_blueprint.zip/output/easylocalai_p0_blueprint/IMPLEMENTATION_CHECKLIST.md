# EasyLocalAI P0 - Checklist d'Implé�®entation

## 📋 Vue d'ensemble
**Objectif**: Socle de fiabilité½½ pour EasyLocalAI  
**Duré½½ estimé½½**: 4 semaines  
**Mode initial**: Audit (enforce=false pour policy et grounding)

---

## ✅ Semaine 1: Tracing E2E

### Fichiers à créer
- [ ] `src/Core/Observability/TraceContext.php`
- [ ] `src/Core/Observability/TelemetryLogger.php`

### Fichiers à modifier
- [ ] `stream.php`
  - [ ] Génè½½er/lire `trace_id` en entrée
  - [ ] Créer `TraceContext` dès le début
  - [ ] Émettre event SSE initial avec `trace_id` et `request_id`
  - [ ] Passer `runtimeContext` à `Agent.run()`
  - [ ] Logger erreurs avec `trace_id`

### Tests
- [ ] Autre requê½½e chat → `trace_id` présent dans SSE
- [ ] `data/agent_traces.jsonl` créá½½ avec events JSONL
- [ ] `GET /public/api_trace.php?trace_id=...` retourne les events

### KPI
- [ ] 100% des requê½½es ont `trace_id`
- [ ] Temps de reconstruction d'un échec < 2 minutes

---

## ✅ Semaine 2: Tool Policy en Audit

### Fichiers à créer
- [ ] `src/Tools/Policy/ToolPolicyEngine.php`
- [ ] `src/Tools/Policy/PolicyDecision.php`

### Fichiers à modifier
- [ ] `bootstrap.php`
  - [ ] Ajouter `use` des nouvelles classes
  - [ ] Enregistrer service `tool_policy_engine`
  - [ ] Charger policies depuis `config/tool_policies.json`
  - [ ] `enforce = false` (mode audit)

- [ ] `ToolRegistry.php`
  - [ ] Étendre constructeur: injecter `ToolPolicyEngine`
  - [ ] Dans `executeTool()`:
    - [ ] Appeler `$policyEngine->evaluate()` avant exé½½ution
    - [ ] Logger decision + exé½½ution + durée
    - [ ] Appeler `$policyEngine->consume()` apré½½s exé½½ution
    - [ ] En audit: ne jamais bloquer, juste logger

### Config à créer
- [ ] `config/tool_policies.json` (exemplaire dans blueprint)
- [ ] `config/settings.json` (ajouts `tool_policy`)

### Tests
- [ ] `GET /public/api_tool_policy_status.php` retourne policies
- [ ] Logs montrent BLOCK/ALLOW sans bloquer réæ½½llement
- [ ] Aucune régressæ½½on fonctionnelle

### KPI
- [ ] 100% des tools ont une policy
- [ ] 0 régressæ½½on observé½½

---

## ✅ Semaine 3: HITL Critical

### Fichiers à créer
- [ ] `src/Core/Safety/HitlGate.php`
- [ ] `src/Core/Safety/HitlRequiredException.php`

### Fichiers à modifier
- [ ] `bootstrap.php`
  - [ ] Enregistrer service `hitl_gate`
  - [ ] Stockage: `data/hitl_decisions.json`

- [ ] `ToolRegistry.php`
  - [ ] Injecter `HitlGate`
  - [ ] Si `permission_level === 'critical'` ou `requires_hitl === true`:
    - [ ] Lancer HITL request
    - [ ] Lancer `HitlRequiredException`

- [ ] `Agent.php`
  - [ ] Catch `HitlRequiredException`
  - [ ] Renvoyer message de suspension propre

- [ ] `stream.php`
  - [ ] Signalement temps réæ½½l HITL

### API à créer
- [ ] `public/api_hitl_request.php`
- [ ] `public/api_hitl_decision.php`
- [ ] `public/api_hitl_pending.php`

### Tests
- [ ] Tool `critical` → HITL request créá½½
- [ ] `POST /api_hitl/request` → `decision_id`
- [ ] `POST /api_hitl/decision` approve → tool exé½½uté½½
- [ ] `POST /api_hitl/decision` reject → tool bloqué½½
- [ ] Timeout → status `timeout`

### KPI
- [ ] 100% des actions critical passent par HITL
- [ ] 0 opération critical non validé½½ en prod

---

## ✅ Semaine 4: Grounding en Audit

### Fichiers à créer
- [ ] `src/Core/Safety/GroundingVerifier.php`

### Fichiers à modifier
- [ ] `bootstrap.php`
  - [ ] Enregistrer service `grounding_verifier`
  - [ ] `enforce = false` (mode audit)

- [ ] `RAG.php`
  - [ ] Retourner chunks structuré½½s:
    - [ ] `source`, `text`, `similarity`, `chunk_id`
  - [ ] Ajouté½½ `getContextWithChunks(string $prompt): array`

- [ ] `Agent.php`
  - [ ] En fin de géí½½é½½ation:
    - [ ] Appeler `$groundingVerifier->verify($answer, $chunks)`
    - [ ] En audit: mesurer support ratio, ne pas bloquer
    - [ ] Ajouter citations compactes si `policy_decision === 'partial'`
    - [ ] En enforce et `reject`: rejeter/reformuler

### Tests
- [ ] Réæ½½onse factuelle → `claims_total`, `claims_supported`
- [ ] `support_ratio` géí½½é½½é½½
- [ ] Citations formaté½½es dans réæ½½onse

### KPI
- [ ] 100% des réæ½½ponses factuelles ont des citations
- [ ] Taux de claims non supporté½½s < 5%
- [ ] Réductæ½½on des hallucinæ½½ons de 50% (tests RAG)

---

## 🎯 Definition of Done Transverse

Pour chaque lot:
- [ ] Feature flag activable/dé½½sactivable
- [ ] Logs structurá½½s avec `trace_id`
- [ ] Tests non-ré½½gression ciblé½½s
- [ ] KPI de lot mesuré½½s avant/apré½½s
- [ ] Rollback simple par config

---

## 📁 Configs à créer

### `config/tool_policies.json`
```json
{
  "tool_web_search": {
    "tool_id": "tool_web_search",
    "permission_level": "read",
    "max_chain_actions": 5,
    "max_calls_per_request": 10,
    "max_duration_ms": 30000,
    "requires_hitl": false
  },
  "tool_file_write": {
    "tool_id": "tool_file_write",
    "permission_level": "write",
    "max_chain_actions": 3,
    "max_calls_per_request": 5,
    "max_duration_ms": 10000,
    "requires_hitl": true
  },
  "tool_deploy": {
    "tool_id": "tool_deploy",
    "permission_level": "critical",
    "max_chain_actions": 1,
    "max_calls_per_request": 1,
    "max_duration_ms": 60000,
    "requires_hitl": true
  }
}
```

### `config/settings.json` (ajouts)
```json
{
  "tool_policy": {
    "enforce": false,
    "default_max_chain_actions": 3,
    "default_max_calls_per_request": 10,
    "default_max_duration_ms": 20000
  },
  "hitl": {
    "default_timeout_seconds": 1800
  },
  "grounding": {
    "enforce": false,
    "min_claim_support_ratio": 0.95
  },
  "observability": {
    "enabled": true,
    "log_path": "data/agent_traces.jsonl"
  }
}
```

---

## 🚀 Transition vers P1

Une fois P0 validé½½:
1. Passer `tool_policy.enforce = true`
2. Passer `grounding.enforce = true`
3. Lancer P1: Query rewriting + Hybrid retrieval + Reranking
