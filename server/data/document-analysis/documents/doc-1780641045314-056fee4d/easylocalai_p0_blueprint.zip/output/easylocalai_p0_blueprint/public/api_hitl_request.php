<?php
/**
 * POST /public/api_hitl_request.php
 * Demande d'approbation HITL
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../vendor/autoload.php';
use EasyLocalAI\Core\Safety\HitlGate;

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
    exit;
}

// Validation required fields
$required = ['trace_id', 'request_id', 'actor_id', 'proposed_action', 'risk_level'];
foreach ($required as $field) {
    if (!isset($input[$field])) {
        echo json_encode(['success' => false, 'error' => "Missing required field: {$field}"]);
        exit;
    }
}

$hitlGate = new HitlGate(storagePath: 'data/hitl_decisions.json');

$result = $hitlGate->requestApproval($input);

echo json_encode($result);
