# EasyLocalAI P0 - Blueprint de Fiabilité½½

## 📦 Contenu
Ce blueprint contient les 7 classes PHP et 5 endpoints API pour le socle de fiabilité½½ P0.

## 📁 Structure
```
easylocalai_p0_blueprint/
├── src/
│   ├── Core/Observability/
│   │   ├── TraceContext.php
│   │   └── TelemetryLogger.php
│   ├── Core/Safety/
│   │   ├── HitlGate.php
│   │   ├── HitlRequiredException.php
│   │   └── GroundingVerifier.php
│   └── Tools/Policy/
│       ├── ToolPolicyEngine.php
│       └── PolicyDecision.php
├── public/
│   ├── api_hitl_request.php
│   ├── api_hitl_decision.php
│   ├── api_hitl_pending.php
│   ├── api_trace.php
│   └── api_tool_policy_status.php
├── config/
│   ├── tool_policies.json
│   └── settings.json
├── IMPLEMENTATION_CHECKLIST.md
└── SUMMARY.json
```

## 🚀 Démarrage Semaine 1 (Tracing E2E)

### 1. Copier les classes dans ton projet
```bash
# Depuis le dossier easylocalai_p0_blueprint
cp -r src/Core/Observability ../your_easylocalai_project/src/Core/
cp -r src/Tools/Policy ../your_easylocalai_project/src/Tools/
cp -r src/Core/Safety ../your_easylocalai_project/src/Core/
cp -r public/* ../your_easylocalai_project/public/
cp config/* ../your_easylocalai_project/config/
```

### 2. Modifier stream.php
Ajouter en début de fichier:
```php
use EasyLocalAI\Core\Observability\TraceContext;
use EasyLocalAI\Core\Observability\TelemetryLogger;

// Créer le contexte de trace
$traceContext = TraceContext::fromHttpRequest($_SERVER, $headers ?? []);
$telemetry = new TelemetryLogger(__DIR__ . '/../data/agent_traces.jsonl');

// Émettre event SSE initial
echo 'data: ' . json_encode([
    'type' => 'trace_info',
    'trace_id' => $traceContext->traceId(),
    'request_id' => $traceContext->requestId()
]) . "\n\n";

// Logger l'é½½vement
$telemetry->logTraceEvent(
    traceId: $traceContext->traceId(),
    requestId: $traceContext->requestId(),
    stage: 'intake',
    status: 'started'
);
```

### 3. Tester
- Faire une requete chat → verifier trace_id dans SSE
- Verifier data/agent_traces.jsonl existe
- Appeler GET /api_trace.php?trace_id=XXX

## 📋 Checklist complète
Ouvrir IMPLEMENTATION_CHECKLIST.md pour la checklist semaine par semaine.

## ⚙️ Configuration
- `config/tool_policies.json` → policies par tool
- `config/settings.json` → enforce=false pour mode audit
