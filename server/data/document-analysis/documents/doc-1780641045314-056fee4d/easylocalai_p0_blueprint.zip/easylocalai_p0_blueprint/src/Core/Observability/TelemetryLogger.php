<?php
namespace EasyLocalAI\Core\Observability;

/**
 * TelemetryLogger - Observability P0
 * Logs structurÃ©s JSONL pour traces agentiques
 */
final class TelemetryLogger
{
    public function __construct(
        private string $logFilePath,
        private bool $enabled = true
    ) {
        $dir = dirname($this->logFilePath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }

    public function log(array $event): void
    {
        if (!$this->enabled) {
            return;
        }

        $event['timestamp_ms'] = round(microtime(true) * 1000);

        if (!isset($event['duration_ms'])) {
            $event['duration_ms'] = 0;
        }

        $jsonLine = json_encode($event, JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
        file_put_contents($this->logFilePath, $jsonLine, FILE_APPEND | LOCK_EX);
    }

    public function logTraceEvent(
        string $traceId,
        string $requestId,
        string $stage,
        string $status,
        int $durationMs = 0,
        ?string $agentId = null,
        ?string $toolId = null,
        ?string $errorCode = null,
        ?string $message = null,
        array $metadata = []
    ): void {
        $event = [
            'trace_id' => $traceId,
            'request_id' => $requestId,
            'stage' => $stage,
            'status' => $status,
            'duration_ms' => $durationMs,
        ];

        if ($agentId !== null) $event['agent_id'] = $agentId;
        if ($toolId !== null) $event['tool_id'] = $toolId;
        if ($errorCode !== null) $event['error_code'] = $errorCode;
        if ($message !== null) $event['message'] = $message;
        if (!empty($metadata)) $event['metadata'] = $metadata;

        $this->log($event);
    }

    public function setEnabled(bool $enabled): void
    {
        $this->enabled = $enabled;
    }
}
