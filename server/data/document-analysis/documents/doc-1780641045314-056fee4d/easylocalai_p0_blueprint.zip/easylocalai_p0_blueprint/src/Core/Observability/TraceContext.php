<?php
namespace EasyLocalAI\Core\Observability;

/**
 * TraceContext - Observability P0
 * Génere et gere trace_id, span_id, requestId pour le tracing E2E
 */
final class TraceContext
{
    public function __construct(
        private string $traceId,
        private string $requestId,
        private ?string $parentSpanId = null,
        private ?string $spanId = null,
        private array $tags = [],
        private float $startedAtMs = 0.0
    ) {
        if ($this->startedAtMs === 0.0) {
            $this->startedAtMs = round(microtime(true) * 1000);
        }
        if ($this->spanId === null) {
            $this->spanId = $this->generateShortId();
        }
    }

    public static function fromHttpRequest(array $server, array $headers = []): self
    {
        $traceId = $headers['X-Trace-Id'] ?? $server['HTTP_X_TRACE_ID'] ?? self::generateTraceIdStatic();
        $requestId = $headers['X-Request-Id'] ?? $server['HTTP_X_REQUEST_ID'] ?? self::generateRequestIdStatic();
        $parentSpanId = $headers['X-Span-Id'] ?? $server['HTTP_X_SPAN_ID'] ?? null;

        return new self(
            traceId: $traceId,
            requestId: $requestId,
            parentSpanId: $parentSpanId
        );
    }

    public static function fromArray(array $payload): self
    {
        return new self(
            traceId: $payload['trace_id'] ?? self::generateTraceIdStatic(),
            requestId: $payload['request_id'] ?? self::generateRequestIdStatic(),
            parentSpanId: $payload['parent_span_id'] ?? null,
            spanId: $payload['span_id'] ?? null,
            tags: $payload['tags'] ?? [],
            startedAtMs: $payload['started_at_ms'] ?? 0.0
        );
    }

    public function traceId(): string { return $this->traceId; }
    public function requestId(): string { return $this->requestId; }
    public function spanId(): string { return $this->spanId; }
    public function parentSpanId(): ?string { return $this->parentSpanId; }

    public function withTag(string $key, string $value): self
    {
        $clone = clone $this;
        $clone->tags[$key] = $value;
        return $clone;
    }

    public function withTags(array $tags): self
    {
        $clone = clone $this;
        $clone->tags = array_merge($clone->tags, $tags);
        return $clone;
    }

    public function childSpan(string $name, array $tags = []): self
    {
        return new self(
            traceId: $this->traceId,
            requestId: $this->requestId,
            parentSpanId: $this->spanId,
            spanId: $this->generateShortId(),
            tags: $tags,
            startedAtMs: round(microtime(true) * 1000)
        );
    }

    public function toArray(): array
    {
        return [
            'trace_id' => $this->traceId,
            'request_id' => $this->requestId,
            'span_id' => $this->spanId,
            'parent_span_id' => $this->parentSpanId,
            'tags' => $this->tags,
            'started_at_ms' => $this->startedAtMs
        ];
    }

    private static function generateTraceIdStatic(): string
    {
        return bin2hex(random_bytes(16));
    }

    private static function generateRequestIdStatic(): string
    {
        return 'req_' . bin2hex(random_bytes(8));
    }

    private function generateShortId(): string
    {
        return bin2hex(random_bytes(8));
    }
}
