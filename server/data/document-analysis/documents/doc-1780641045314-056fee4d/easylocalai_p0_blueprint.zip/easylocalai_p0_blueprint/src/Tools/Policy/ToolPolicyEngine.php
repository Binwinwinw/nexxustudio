<?php
namespace EasyLocalAI\Tools\Policy;

/**
 * ToolPolicyEngine - FiabilitÃ© P0
 * GÃ¨re permissions, budgets, limites de chaÃ®ne d'actions
 */
final class ToolPolicyEngine
{
    private array $policiesByToolId = [];
    private bool $enforce = false;

    public function __construct(
        array $policies = [],
        private int $defaultMaxChainActions = 3,
        private int $defaultMaxCallsPerRequest = 10,
        private int $defaultMaxDurationMs = 20000,
        bool $enforce = false
    ) {
        $this->enforce = $enforce;
        foreach ($policies as $policy) {
            $this->upsertPolicy($policy);
        }
    }

    public function setEnforce(bool $enforce): void
    {
        $this->enforce = $enforce;
    }

    public function isEnforce(): bool
    {
        return $this->enforce;
    }

    public function upsertPolicy(array $policy): void
    {
        if (!isset($policy['tool_id'])) {
            throw new \InvalidArgumentException('tool_id is required');
        }

        $this->policiesByToolId[$policy['tool_id']] = [
            'tool_id' => $policy['tool_id'],
            'permission_level' => $policy['permission_level'] ?? 'read',
            'max_chain_actions' => $policy['max_chain_actions'] ?? $this->defaultMaxChainActions,
            'max_calls_per_request' => $policy['max_calls_per_request'] ?? $this->defaultMaxCallsPerRequest,
            'max_duration_ms' => $policy['max_duration_ms'] ?? $this->defaultMaxDurationMs,
            'requires_hitl' => $policy['requires_hitl'] ?? false,
            'estimated_token_cost' => $policy['estimated_token_cost'] ?? 0,
            'allowed_paths' => $policy['allowed_paths'] ?? [],
            'denied_args_patterns' => $policy['denied_args_patterns'] ?? [],
            'notes' => $policy['notes'] ?? ''
        ];
    }

    public function getPolicy(string $toolId): array
    {
        if (!isset($this->policiesByToolId[$toolId])) {
            return [
                'tool_id' => $toolId,
                'permission_level' => 'read',
                'max_chain_actions' => $this->defaultMaxChainActions,
                'max_calls_per_request' => $this->defaultMaxCallsPerRequest,
                'max_duration_ms' => $this->defaultMaxDurationMs,
                'requires_hitl' => false,
                'estimated_token_cost' => 0,
                'allowed_paths' => [],
                'denied_args_patterns' => [],
                'notes' => 'Default policy'
            ];
        }
        return $this->policiesByToolId[$toolId];
    }

    public function getAllPolicies(): array
    {
        return array_values($this->policiesByToolId);
    }

    public function evaluate(
        string $toolId,
        array $args,
        array $requestBudgetState,
        array $requestActionState
    ): PolicyDecision {
        $policy = $this->getPolicy($toolId);

        // Check permission level
        if ($policy['permission_level'] === 'critical' && !$policy['requires_hitl']) {
            if ($this->enforce) {
                return new PolicyDecision(
                    allowed: false,
                    reasonCode: 'REQUIRES_HITL',
                    message: 'Critical tool requires HITL approval',
                    permissionLevel: 'critical',
                    requiresHitl: true
                );
            }
        }

        // Check requires_hitl flag
        if ($policy['requires_hitl']) {
            if ($this->enforce) {
                return new PolicyDecision(
                    allowed: false,
                    reasonCode: 'REQUIRES_HITL',
                    message: 'Tool requires HITL approval',
                    permissionLevel: $policy['permission_level'],
                    requiresHitl: true
                );
            }
        }

        // Check call count limit
        $callsInRequest = $requestActionState['calls_count'] ?? 0;
        if ($callsInRequest >= $policy['max_calls_per_request']) {
            if ($this->enforce) {
                return new PolicyDecision(
                    allowed: false,
                    reasonCode: 'BLOCK_BUDGET_CALLS',
                    message: 'Maximum calls per request exceeded',
                    permissionLevel: $policy['permission_level'],
                    requiresHitl: false
                );
            }
        }

        // Check duration budget
        $durationUsed = $requestBudgetState['duration_ms'] ?? 0;
        if ($durationUsed >= $policy['max_duration_ms']) {
            if ($this->enforce) {
                return new PolicyDecision(
                    allowed: false,
                    reasonCode: 'BLOCK_BUDGET_DURATION',
                    message: 'Maximum duration exceeded',
                    permissionLevel: $policy['permission_level'],
                    requiresHitl: false
                );
            }
        }

        // Check chain action limit
        $actionsInChain = $requestActionState['actions_in_chain'] ?? 0;
        if ($actionsInChain >= $policy['max_chain_actions']) {
            if ($this->enforce) {
                return new PolicyDecision(
                    allowed: false,
                    reasonCode: 'BLOCK_CHAIN_LIMIT',
                    message: 'Maximum chain actions exceeded',
                    permissionLevel: $policy['permission_level'],
                    requiresHitl: false
                );
            }
        }

        return new PolicyDecision(
            allowed: true,
            reasonCode: 'ALLOW',
            message: 'Tool execution allowed',
            permissionLevel: $policy['permission_level'],
            requiresHitl: $policy['requires_hitl']
        );
    }

    public function consume(
        string $toolId,
        int $durationMs,
        int $estimatedTokens,
        array &$requestBudgetState,
        array &$requestActionState
    ): void {
        $requestBudgetState['duration_ms'] = ($requestBudgetState['duration_ms'] ?? 0) + $durationMs;
        $requestBudgetState['tokens'] = ($requestBudgetState['tokens'] ?? 0) + $estimatedTokens;
        $requestActionState['calls_count'] = ($requestActionState['calls_count'] ?? 0) + 1;
        $requestActionState['actions_in_chain'] = ($requestActionState['actions_in_chain'] ?? 0) + 1;
    }
}
