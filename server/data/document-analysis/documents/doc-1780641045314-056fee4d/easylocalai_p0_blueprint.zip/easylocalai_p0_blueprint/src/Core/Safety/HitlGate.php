<?php
namespace EasyLocalAI\Core\Safety;

/**
 * HitlGate - FiabilitÃ© P0
 * GÃ¨re les demandes d'approbation humaine pour actions sensibles
 */
final class HitlGate
{
    private string $storagePath;
    private int $defaultTimeoutSeconds;

    public function __construct(
        string $storagePath,
        int $defaultTimeoutSeconds = 1800
    ) {
        $this->storagePath = $storagePath;
        $this->defaultTimeoutSeconds = $defaultTimeoutSeconds;

        $dir = dirname($this->storagePath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }

    public function requestApproval(array $payload): array
    {
        $decisionId = 'hitl_' . bin2hex(random_bytes(8));
        $createdAt = time();
        $expiresAt = $createdAt + ($payload['timeout_seconds'] ?? $this->defaultTimeoutSeconds);

        $decision = [
            'decision_id' => $decisionId,
            'trace_id' => $payload['trace_id'],
            'request_id' => $payload['request_id'],
            'actor_id' => $payload['actor_id'],
            'proposed_action' => $payload['proposed_action'],
            'risk_level' => $payload['risk_level'],
            'timeout_seconds' => $payload['timeout_seconds'] ?? $this->defaultTimeoutSeconds,
            'status' => 'pending',
            'created_at' => date('Y-m-d\TH:i:sP', $createdAt),
            'expires_at' => date('Y-m-d\TH:i:sP', $expiresAt),
            'decided_at' => null,
            'decided_by' => null,
            'decision' => null,
            'reason' => null
        ];

        $this->saveDecision($decisionId, $decision);

        return [
            'success' => true,
            'decision_id' => $decisionId,
            'status' => 'pending',
            'expires_at' => $decision['expires_at']
        ];
    }

    public function decide(string $decisionId, string $decision, string $actorId, ?string $reason = null): array
    {
        $decisions = $this->loadAllDecisions();

        if (!isset($decisions[$decisionId])) {
            return [
                'success' => false,
                'error' => 'Decision not found'
            ];
        }

        $decodedDecision = $decisions[$decisionId];
        if ($decodedDecision['status'] !== 'pending') {
            return [
                'success' => false,
                'error' => 'Decision already made'
            ];
        }

        $decodedDecision['status'] = $decision === 'approve' ? 'approved' : 'rejected';
        $decodedDecision['decided_at'] = date('Y-m-d\TH:i:sP', time());
        $decodedDecision['decided_by'] = $actorId;
        $decodedDecision['decision'] = $decision;
        $decodedDecision['reason'] = $reason;

        $this->saveDecision($decisionId, $decodedDecision);

        return [
            'success' => true,
            'decision_id' => $decisionId,
            'status' => $decodedDecision['status'],
            'decided_at' => $decodedDecision['decided_at']
        ];
    }

    public function get(string $decisionId): ?array
    {
        $decisions = $this->loadAllDecisions();
        return $decisions[$decisionId] ?? null;
    }

    public function listPending(int $limit = 50): array
    {
        $decisions = $this->loadAllDecisions();
        $pending = [];

        foreach ($decisions as $decisionId => $decision) {
            if ($decision['status'] === 'pending') {
                if (time() > strtotime($decision['expires_at'])) {
                    $decision['status'] = 'timeout';
                    $this->saveDecision($decisionId, $decision);
                    continue;
                }
                $pending[] = $decision;
            }
        }

        usort($pending, fn($a, $b) => strtotime($a['created_at']) - strtotime($b['created_at']));

        return array_slice($pending, 0, $limit);
    }

    public function requireOrThrow(
        string $toolId,
        array $args,
        string $traceId,
        string $requestId,
        string $riskLevel = 'medium'
    ): void {
        $decisionId = 'hitl_' . bin2hex(random_bytes(8));

        throw new HitlRequiredException(
            $decisionId,
            "HITL approval required for tool: {$toolId}"
        );
    }

    private function saveDecision(string $decisionId, array $decision): void
    {
        $decisions = $this->loadAllDecisions();
        $decisions[$decisionId] = $decision;
        file_put_contents(
            $this->storagePath,
            json_encode($decisions, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
            LOCK_EX
        );
    }

    private function loadAllDecisions(): array
    {
        if (!file_exists($this->storagePath)) {
            return [];
        }

        $content = file_get_contents($this->storagePath);
        if (empty($content)) {
            return [];
        }

        $decoded = json_decode($content, true);
        return is_array($decoded) ? $decoded : [];
    }
}
