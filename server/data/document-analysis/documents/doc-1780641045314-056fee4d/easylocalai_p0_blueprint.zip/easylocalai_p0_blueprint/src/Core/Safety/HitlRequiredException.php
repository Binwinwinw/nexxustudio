<?php
namespace EasyLocalAI\Core\Safety;

/**
 * HitlRequiredException - FiabilitÃ© P0
 * Exception lancÃ©e quand une approbation HITL est requise
 */
final class HitlRequiredException extends \RuntimeException
{
    public function __construct(
        private string $decisionId,
        string $message = 'HITL approval required'
    ) {
        parent::__construct($message);
    }

    public function decisionId(): string
    {
        return $this->decisionId;
    }
}
