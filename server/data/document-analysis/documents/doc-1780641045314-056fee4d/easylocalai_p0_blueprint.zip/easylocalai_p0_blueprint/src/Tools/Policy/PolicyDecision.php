<?php
namespace EasyLocalAI\Tools\Policy;

/**
 * PolicyDecision - FiabilitÃ© P0
 * ReprÃ©sente la dÃ©cision d'une politique de tool
 */
final class PolicyDecision
{
    public function __construct(
        private bool $allowed,
        private string $reasonCode,
        private string $message,
        private string $permissionLevel,
        private bool $requiresHitl = false
    ) {}

    public function allowed(): bool { return $this->allowed; }
    public function reasonCode(): string { return $this->reasonCode; }
    public function message(): string { return $this->message; }
    public function permissionLevel(): string { return $this->permissionLevel; }
    public function requiresHitl(): bool { return $this->requiresHitl; }

    public function toArray(): array
    {
        return [
            'allowed' => $this->allowed,
            'reason_code' => $this->reasonCode,
            'message' => $this->message,
            'permission_level' => $this->permissionLevel,
            'requires_hitl' => $this->requiresHitl
        ];
    }
}
