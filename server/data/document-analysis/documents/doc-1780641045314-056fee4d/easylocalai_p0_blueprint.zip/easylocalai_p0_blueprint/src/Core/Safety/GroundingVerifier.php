<?php
namespace EasyLocalAI\Core\Safety;

/**
 * GroundingVerifier - FiabilitÃ© P0
 * VÃ©rifie que les claims de la rÃ©ponse sont supportÃ©s par les chunks retrieved
 */
final class GroundingVerifier
{
    public function __construct(
        private float $minClaimSupportRatio = 0.95,
        private bool $enforce = false
    ) {}

    public function setEnforce(bool $enforce): void
    {
        $this->enforce = $enforce;
    }

    public function isEnforce(): bool
    {
        return $this->enforce;
    }

    public function verify(
        string $answer,
        array $retrievedChunks,
        array $options = []
    ): array {
        $claims = $this->extractClaims($answer);
        $supportedClaims = 0;
        $citations = [];

        foreach ($claims as $claim) {
            $supportResult = $this->findSupportForClaim($claim, $retrievedChunks);

            if ($supportResult['supported']) {
                $supportedClaims++;
                $citations[] = [
                    'claim' => $claim,
                    'source' => $supportResult['source'],
                    'chunk_id' => $supportResult['chunk_id'],
                    'confidence' => $supportResult['confidence']
                ];
            }
        }

        $claimsTotal = count($claims);
        $supportRatio = $claimsTotal > 0 ? $supportedClaims / $claimsTotal : 1.0;

        $policyDecision = $supportRatio >= $this->minClaimSupportRatio 
            ? 'pass' 
            : ($this->enforce ? 'reject' : 'partial');

        return [
            'claims_total' => $claimsTotal,
            'claims_supported' => $supportedClaims,
            'unsupported_claims' => $claimsTotal - $supportedClaims,
            'support_ratio' => $supportRatio,
            'citations' => $citations,
            'policy_decision' => $policyDecision
        ];
    }

    public function formatCitations(string $answer, array $verification): string
    {
        if (empty($verification['citations'])) {
            return $answer;
        }

        $formattedAnswer = $answer;
        foreach ($verification['citations'] as $index => $citation) {
            $marker = "[{$index + 1}]";
            $formattedAnswer .= " {$marker}<sup>source:{$citation['chunk_id']}</sup>";
        }

        return $formattedAnswer;
    }

    private function extractClaims(string $answer): array
    {
        $sentences = preg_split('/[.!?]+/', $answer);
        $claims = [];

        foreach ($sentences as $sentence) {
            $sentence = trim($sentence);
            if (strlen($sentence) > 20) {
                $claims[] = $sentence;
            }
        }

        return $claims;
    }

    private function findSupportForClaim(string $claim, array $chunks): array
    {
        foreach ($chunks as $chunk) {
            $chunkText = $chunk['text'] ?? '';

            if (stripos($chunkText, $claim) !== false) {
                return [
                    'supported' => true,
                    'source' => $chunk['source'] ?? 'unknown',
                    'chunk_id' => $chunk['chunk_id'] ?? 'unknown',
                    'confidence' => 0.9
                ];
            }

            $similarity = $this->computeSimilarity($claim, $chunkText);
            if ($similarity > 0.7) {
                return [
                    'supported' => true,
                    'source' => $chunk['source'] ?? 'unknown',
                    'chunk_id' => $chunk['chunk_id'] ?? 'unknown',
                    'confidence' => $similarity
                ];
            }
        }

        return [
            'supported' => false,
            'source' => null,
            'chunk_id' => null,
            'confidence' => 0.0
        ];
    }

    private function computeSimilarity(string $a, string $b): float
    {
        $a = strtolower($a);
        $b = strtolower($b);

        $wordsA = preg_split('/\s+/', $a, -1, PREG_SPLIT_NO_EMPTY);
        $wordsB = preg_split('/\s+/', $b, -1, PREG_SPLIT_NO_EMPTY);

        $setA = array_flip($wordsA);
        $setB = array_flip($wordsB);

        $intersection = array_intersect_key($setA, $setB);
        $union = array_merge($setA, $setB);

        if (empty($union)) {
            return 0.0;
        }

        return count($intersection) / count($union);
    }
}
