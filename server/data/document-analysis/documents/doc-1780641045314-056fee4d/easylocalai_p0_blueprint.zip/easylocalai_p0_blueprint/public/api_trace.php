<?php
/**
 * GET /public/api_trace.php?trace_id=...
 * RÃ©cupÃ¨re tous les events d'une trace
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../vendor/autoload.php';

$traceId = $_GET['trace_id'] ?? '';

if (empty($traceId)) {
    echo json_encode(['success' => false, 'error' => 'Missing trace_id']);
    exit;
}

$logFile = __DIR__ . '/../data/agent_traces.jsonl';
$events = [];

if (file_exists($logFile)) {
    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $event = json_decode($line, true);
        if ($event && ($event['trace_id'] ?? '') === $traceId) {
            $events[] = $event;
        }
    }
}

echo json_encode([
    'success' => true,
    'trace_id' => $traceId,
    'events' => $events
]);
