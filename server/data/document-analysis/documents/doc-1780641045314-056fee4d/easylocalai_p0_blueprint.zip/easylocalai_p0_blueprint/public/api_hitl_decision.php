<?php
/**
 * POST /public/api_hitl_decision.php
 * DÃ©cision HITL (approve/reject)
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../vendor/autoload.php';
use EasyLocalAI\Core\Safety\HitlGate;

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'error' => 'Invalid JSON']);
    exit;
}

if (!isset($input['decision_id'], $input['decision'], $input['actor_id'])) {
    echo json_encode(['success' => false, 'error' => 'Missing required fields']);
    exit;
}

if (!in_array($input['decision'], ['approve', 'reject'])) {
    echo json_encode(['success' => false, 'error' => 'Decision must be approve or reject']);
    exit;
}

$hitlGate = new HitlGate(storagePath: __DIR__ . '/../data/hitl_decisions.json');

$result = $hitlGate->decide(
    decisionId: $input['decision_id'],
    decision: $input['decision'],
    actorId: $input['actor_id'],
    reason: $input['reason'] ?? null
);

echo json_encode($result);
