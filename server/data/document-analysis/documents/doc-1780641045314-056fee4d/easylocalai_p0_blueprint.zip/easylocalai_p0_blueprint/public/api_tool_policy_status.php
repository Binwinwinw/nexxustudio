<?php
/**
 * GET /public/api_tool_policy_status.php
 * Statut des politiques de tools
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../vendor/autoload.php';
use EasyLocalAI\Tools\Policy\ToolPolicyEngine;

// Charger policy engine (sans enforce pour lecture)
$policiesFile = __DIR__ . '/../config/tool_policies.json';
$policies = [];
if (file_exists($policiesFile)) {
    $policies = json_decode(file_get_contents($policiesFile), true) ?? [];
}

$policyEngine = new ToolPolicyEngine(policies: $policies, enforce: false);

echo json_encode([
    'success' => true,
    'enforce' => $policyEngine->isEnforce(),
    'policies' => $policyEngine->getAllPolicies()
]);
