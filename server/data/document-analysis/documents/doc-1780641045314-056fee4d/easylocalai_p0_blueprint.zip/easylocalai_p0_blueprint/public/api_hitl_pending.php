<?php
/**
 * GET /public/api_hitl_pending.php
 * Liste des demandes HITL en attente
 */
header('Content-Type: application/json');

require_once __DIR__ . '/../vendor/autoload.php';
use EasyLocalAI\Core\Safety\HitlGate;

$limit = $_GET['limit'] ?? 50;

$hitlGate = new HitlGate(storagePath: __DIR__ . '/../data/hitl_decisions.json');

$pending = $hitlGate->listPending(limit: (int)$limit);

echo json_encode([
    'success' => true,
    'items' => $pending
]);
